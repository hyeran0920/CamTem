package com.camtem.camtemback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CamtemBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(CamtemBackApplication.class, args);
	}

}
