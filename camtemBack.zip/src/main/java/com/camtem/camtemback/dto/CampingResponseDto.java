package com.camtem.camtemback.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CampingResponseDto {
    private int contentId;
    private String facltNm;
    private String intro;
    private String firstImageUrl;
    private String addr1;
    private String lineIntro;
    private String induty;
}
