package com.camtem.camtemback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CamtemBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
